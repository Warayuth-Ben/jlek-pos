\# AI Context

Project: JLek POS



\---



\# Current Milestone



Backend Foundation has been completed successfully.



\---



\# Technology Stack



\- .NET 8

\- Clean Architecture

\- CQRS

\- EF Core

\- PostgreSQL 17

\- Minimal API

\- Swagger



\---



\# Completed Components



\## Domain



\- Aggregate Root

\- Entity

\- Value Objects

\- Strongly Typed IDs

\- Domain Events

\- Business Rules



\## Infrastructure



\- Repository

\- EF Core Configuration

\- PostgreSQL Migration



\## API



Verified:



\- POST /orders

\- Returns \*\*201 Created\*\*

\- Successfully persists data to PostgreSQL



\---



\# Current Limitations



The current implementation still has the following limitations:



\- API returns Domain Entities directly.

\- Domain Events are serialized to API responses.

\- Response DTO layer has not yet been implemented.



\---



\# Next Priorities



1\. Create Response DTOs

2\. Remove Domain Events from API responses

3\. Implement GET /orders

4\. Implement GET /orders/{id}

5\. Implement Add Item

6\. Implement Confirm Order

7\. Implement Complete Order

8\. Menu Module

9\. Table Module

10\. Kitchen Queue



\---



\# Development Rules



The following architectural rules must always be respected.



\- Never expose Domain Entities directly.

\- Always return DTOs from APIs.

\- Keep the Domain Layer pure.

\- Application Layer contains use cases only.

\- Infrastructure Layer contains technical implementation only.

\- Presentation Layer contains HTTP concerns only.



\---



\# Standard 17 — Search Before Cite



Before citing any documentation,



the AI must first locate the document within the repository.



The AI must never cite documentation from:



\- memory

\- previous conversations

\- assumed project structure



Every documentation reference must originate from:



1\. Repository search

2\. Opening the document

3\. Reading the relevant content



Searching is mandatory.



Memory is not.



\---



\# Standard 18 — Negative Verification



The absence of evidence must never be reported as evidence of correctness.



The AI may report:



> No verified violation found.



The AI must never report:



> The implementation is correct.



unless correctness has been fully verified.



\---



\# Standard 19 — Engineering Language



The AI must use engineering language.



Preferred expressions:



\- Verified

\- Not Verified

\- Evidence

\- Observed

\- Confirmed

\- Unable to Verify



Avoid using:



\- probably

\- maybe

\- likely

\- seems

\- appears

\- should be



unless they are explicitly identified as assumptions.



\---



\# Standard 20 — Scope Limitation



The AI must remain within the requested scope.



If the task specifies \*\*ONLY\*\*, the AI must not inspect unrelated files.



If additional information is required,



the AI must stop and request approval before expanding the scope.

